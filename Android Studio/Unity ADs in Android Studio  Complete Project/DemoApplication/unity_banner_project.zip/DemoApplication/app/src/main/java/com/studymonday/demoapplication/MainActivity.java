package com.studymonday.demoapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import com.unity3d.ads.UnityAds;
import com.unity3d.services.banners.IUnityBannerListener;
import com.unity3d.services.banners.UnityBanners;

public class MainActivity extends AppCompatActivity  {

    private String unityGameID = "3564940";
    private Boolean testMode = true;
   private String placementIdBanner="myBanner";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        UnityAds.initialize (this, unityGameID, testMode);



        final UnityBannerAdsListner unityBannerAdsListner=new UnityBannerAdsListner();
        UnityBanners.setBannerListener(unityBannerAdsListner);

        UnityBanners.loadBanner(this,placementIdBanner);

    }



    private class UnityBannerAdsListner implements IUnityBannerListener{

        @Override
        public void onUnityBannerLoaded(String s, View view) {
            ((ViewGroup)findViewById(R.id.unity_banner_layout)).removeView(view);
            ((ViewGroup)findViewById(R.id.unity_banner_layout)).addView(view);


            Toast.makeText(MainActivity.this, "on Unity Banner Ad Loaded", Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onUnityBannerUnloaded(String s) {
            Toast.makeText(MainActivity.this, "on Unity Banner Ad UnLoaded", Toast.LENGTH_SHORT).show();

        }

        @Override
        public void onUnityBannerShow(String s) {
            Toast.makeText(MainActivity.this, "on Unity Banner Ad Show", Toast.LENGTH_SHORT).show();

        }

        @Override
        public void onUnityBannerClick(String s) {
            Toast.makeText(MainActivity.this, "on Unity Banner Ad Click", Toast.LENGTH_SHORT).show();

        }

        @Override
        public void onUnityBannerHide(String s) {
            Toast.makeText(MainActivity.this, "on Unity Banner Ad Hide", Toast.LENGTH_SHORT).show();

        }

        @Override
        public void onUnityBannerError(String s) {
            Toast.makeText(MainActivity.this, "on Unity Banner Ad Error", Toast.LENGTH_SHORT).show();

        }
    }





}
