package com.studymonday.demoapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.unity3d.ads.IUnityAdsListener;
import com.unity3d.ads.UnityAds;

public class MainActivity extends AppCompatActivity  {

    private String unityGameID = "3564940";
    private Boolean testMode = true;
    private String placementIdSkippedVideo="video";

    Button showSkippedVideoAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final UnityAdsListener myAdsListener = new UnityAdsListener ();

        UnityAds.initialize (this, unityGameID, myAdsListener, testMode);

        showSkippedVideoAd=(Button)findViewById(R.id.showSkippedVideoBtn);
        showSkippedVideoAd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LoadshowSkippedVideoAd();
            }
        });
    }

    public void LoadshowSkippedVideoAd()
    {
        UnityAds.load(placementIdSkippedVideo);

        if(UnityAds.isReady(placementIdSkippedVideo))
        {
            UnityAds.show(this,placementIdSkippedVideo);
        }
    }





    private class UnityAdsListener implements IUnityAdsListener {

        @Override
        public void onUnityAdsReady (String placementId) {
            Toast.makeText(MainActivity.this, "onUnityAdsReady", Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onUnityAdsStart (String placementId) {
            Toast.makeText(MainActivity.this, "onUnityAdsStart", Toast.LENGTH_SHORT).show();

        }

        @Override
        public void onUnityAdsFinish (String placementId, UnityAds.FinishState finishState) {
            Toast.makeText(MainActivity.this, "onUnityAdsFinish", Toast.LENGTH_SHORT).show();

        }

        @Override
        public void onUnityAdsError (UnityAds.UnityAdsError error, String message) {
            Toast.makeText(MainActivity.this, "onUnityAdsError", Toast.LENGTH_SHORT).show();

        }
    }



}
